#include <stdio.h>
#include <stdlib.h>
//#include <math.h>
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"

//#define PROB 0.01
//#define TMAX 100
//#define TMIN 2
// Gera um vizinho
// Parametros: solucao actual, vizinho, numero de vertices
//swap two vertices
void gera_vizinho(int a[], int b[], int n, int *mat, int num_iter)
{
    int i, j, x, y, w = 0;

    for(i=0; i<n; i++)
        b[i]=a[i];

        w = 1;

        do {

            x = random_l_h(1, n-1);
            //y = random_l_h(1, num_iter-1);
            for (j=0; j<n;j++){
                //printf("\nx %d j %d b %d w %d", x, j, *(b+j), w);
                for (i = 0; i < n; i++) { // Para cada subconjunto
                    if (*(b + i)==0) {
                        if (*(mat + x + (i * x)) == 1) {
                            w = 1;
                        }else{w = 0;}
                    }
                }

                if (*(mat + x + (j * x)) == 1) {
                    w = 1;
                }else{w = 0;}

                //printf("\ni %d *b %d w %d", i, *(b+i), w);

            }
        } while (w!=0);
    *(b+(x)) = 0;
    //*(b+(y)) = 1;
   /*

    do {

        y = random_l_h(1, n-1);
        //y = random_l_h(1, num_iter-1);

            //printf("\nx %d j %d b %d w %d", x, j, *(b+j), w);
                if (*(b + y)==1) {
                        w = 0;
                }else{w = 1;}



    } while (w==0);
    */

        //*(b+(y)) = 1;

}


// Trepa colinas first-choice
// Parametros: solucao, matriz de adjacencias, numero de vertices e numero de iteracoes
// Devolve o custo da melhor solucao encontrada
int trepa_colinas(int sol[], int *mat, int vert, int num_iter)
{
    int  custo, custo_viz, i;
    int *nova_sol;
    // Avalia solucao inicial
    nova_sol = malloc(sizeof(int)*vert+(1));
    if(nova_sol == NULL)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }
    //printf("\n\t\t\t\t\t%d", *nova_sol);
    //nova_sol = malloc(sizeof(int)*vert);

    custo = calcula_fit(sol, mat, vert, num_iter);

    //for (i = 0; i < num_iter; i++) { // Para cada subconjunto
        // Gera vizinho
        gera_vizinho(sol, nova_sol, vert, mat, num_iter);
        // Avalia vizinho
        custo_viz = calcula_fit(sol, mat, vert, num_iter);
        // Aceita vizinho se o custo diminuir (problema de minimizacao)
        if (custo_viz > custo) {
            substitui(sol, nova_sol, vert);
            custo = custo_viz;
        }
   // }
    free(nova_sol);
    return custo;
}

