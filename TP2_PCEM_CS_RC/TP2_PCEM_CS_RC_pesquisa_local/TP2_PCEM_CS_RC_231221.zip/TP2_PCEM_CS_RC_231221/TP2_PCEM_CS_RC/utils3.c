//
// Created by quimi on 19/12/2021.
//

// Trabalho Pratico IIA - LEI
// DEIS-ISEC 2021-2022
/*
 * Authors:
 * Carlos Santos
 * Email: a2003035578@isec.pt
 * Rodrigo Costa
 * Email: a2020133365@isec.pt
 * Created on: 18/12/2021
 * Last Edit: 18/12/2021
 */
/*
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "utils.h"

// Leitura do ficheiro de input
// Recebe: nome do ficheiro, numero de vertices (ptr), numero de iteracoes (ptr)
// Devolve a matriz de adjacencias
int *init_dados(char *nome, int *n, int *iter) {
    FILE *f;
    int *p, *q;
    int i, j;
    int aux1 = 0;
    int aux2 = 0;
    char aux_inicio;
    char str1[10];
    int iter1, n1;
    int count=1, count2=1;;

    f = fopen(nome, "r");
    if (!f) {
        printf("Erro no acesso ao ficheiro dos dados\n");
        exit(1);
    }

    // Numero de iteracoes

    while (fscanf(f, "%c", &aux_inicio) != EOF) {

        if (aux_inicio == 'p') {
            if (fscanf(f, " edge %d %d", n, iter))
                break;
        }
    }
    fclose(f);
    //printf("c: %d\tp: %d\n",countC, countP);



    // Numero de vertices
    // fscanf(f, " %d", n);
    // Alocacao dinamica da matriz
    p = malloc(sizeof(int) * (((*n) * (*iter))+1));
    if (!p) {
        printf("Erro na alocacao de memoria\n");
        exit(1);
    }


    // printf("iter %d- n %d\n", *iter, *n);

    q = p;



    //printf("n %d\n", *n);
    // Preenchimento da matriz
    f = fopen(nome, "r");
    if (!f) {
        printf("Erro no acesso ao ficheiro dos dados\n");
        exit(1);
    }


    while (fscanf(f, "%c", &aux_inicio) != EOF) {

        if (aux_inicio == 'p') {

            if (fscanf(f, " edge %d %d", n, iter)) {
                //continue;
                break;
            }
        }
    }
    while (fscanf(f, "%c", &aux_inicio) != EOF) {
        if (aux_inicio == 'e') {
            fscanf(f, "%d",&aux1);
            fscanf(f, "%d", &aux2);
            //printf("%d ---- %d\n",aux1, aux2);
            i = aux1;
            // printf("i %d\n", i);

        }

        for (j = 1; j <= *n; j++) {
            // printf("j %d\n", j);

            //printf("aux1 %d- aux2 %d  ----> i %d --- j %d \n", aux1, aux2, i, j);
            if (aux2 == j) {
                if ( i != j ) {
                    q++;
                    *q = 0;
                    printf("i %d- j %d\n",i, j);
                    //printf("\t\t q %d ---->q %d --- count++ %d\n", *q, q, count++);
                    printf("\t i==j %d ---->j %d\n", *q, j);
                }
            } else {
                if ( i != j ){
                    q++;
                    *q = 1;
                    //printf("\t\t q %d ---->q %d --- count++ %d\n", *q, q, count++);
                    printf("\t\t i!=j %d -i--> %d --->j %d ----- count %d\n", *q, i, j, count2++);
                }
            }
        }

    }


    //printf("iter %d- n %d\n", *iter, *n); //funcionar
    fclose(f);
    return p;
}

// Gera a solucao inicial
// Parametros: solucao, numero de vertices
void gera_sol_inicial(int *sol, int v) {
    int i, x;

    for (i = 1; i < v; i++)
        sol[i] = 0;
    for (i = 1; i < v / 2; i++) {
        do
            x = random_l_h(0, v - 1);
        while (sol[x] != 0);
        sol[x] = 1;
    }
}

// Escreve solucao
// Parametros: solucao e numero de vertices
void escreve_sol(int *sol, int vert) {
    int i;

    printf("\nConjunto A: ");
    for (i = 0; i < vert; i++)
        if (sol[i] == 0)
            printf("%2d  ", i);
    printf("\nConjunto B: ");
    for (i = 0; i < vert; i++)
        if (sol[i] == 1)
            printf("%2d  ", i);
    printf("\n");
}

// copia vector b para a (tamanho n)
void substitui(int a[], int b[], int n) {
    int i;
    for (i = 0; i < n; i++)
        a[i] = b[i];
}

// Inicializa o gerador de numeros aleatorios
void init_rand() {
    srand((unsigned) time(NULL));
}

// Devolve valor inteiro aleatorio entre min e max
int random_l_h(int min, int max) {
    return min + rand() % (max - min + 1);
}

// Devolve um valor real aleatorio do intervalo [0, 1]
float rand_01() {
    return ((float) rand()) / RAND_MAX;
}
*/