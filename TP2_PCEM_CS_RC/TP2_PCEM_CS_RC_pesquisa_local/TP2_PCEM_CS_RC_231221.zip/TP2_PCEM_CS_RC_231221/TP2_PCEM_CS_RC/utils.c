// Trabalho Pratico IIA - LEI
// DEIS-ISEC 2021-2022
/*
 * Authors:
 * Carlos Santos
 * Email: a2003035578@isec.pt
 * Rodrigo Costa
 * Email: a2020133365@isec.pt
 * Created on: 18/12/2021
 * Last Edit: 18/12/2021
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "utils.h"

// Leitura do ficheiro de input
// Recebe: nome do ficheiro, numero de vertices (ptr), numero de iteracoes (ptr)
// Devolve a matriz de adjacencias
int *init_dados(char *nome, int *n, int *iter) {
    FILE *f;
    int *p, *q, *p_orig, *q_orig;
    int i, j, k, x, h;
    int aux1 = 0;
    int aux2 = 0;
    int iter1, n1;
    int count = 1, count2 = 1;;

    int arrayAux1[2];
    int arrayAux2[2];
    char aux_inicio;
    char str1[10];

    f = fopen(nome, "r");
    if (!f) {
        printf("Erro no acesso ao ficheiro dos dados\n");
        exit(1);
    }

    // Numero de iteracoes

    while (fscanf(f, "%c", &aux_inicio) != EOF) {
        if (aux_inicio == 'p') {
            if (fscanf(f, " edge %d %d", n, iter))
                break;
        }
    }
    fclose(f);
    // Numero de vertices
    // fscanf(f, " %d", n);
    // Alocacao dinamica da matriz
    p = malloc(sizeof(int) * (((*iter) * (*iter))+1));
    if (!p) {
        printf("Erro na alocacao de memoria\n");
        exit(1);
    }

    p_orig = malloc(sizeof(int) * (((*iter) * (*iter)+1)));
    if (!p_orig) {
        printf("Erro na alocacao de memoria\n");
        exit(1);
    }

    q = p;
    q_orig = p_orig;

    //printf("n %d\n", *n);
    // Preenchimento da matriz
    f = fopen(nome, "r");
    if (!f) {
        printf("Erro no acesso ao ficheiro dos dados\n");
        exit(1);
    }

    while (fscanf(f, "%c", &aux_inicio) != EOF) {

        if (aux_inicio == 'p') {

            if (fscanf(f, " edge %d %d", n, iter)) {
                //continue;
                break;
            }
        }
    }

    while (fscanf(f, "%c", &aux_inicio) != EOF) {
        if (aux_inicio == 'e') {
            fscanf(f, "%d", &aux1);
            fscanf(f, "%d", &aux2);
            //printf("%d ---- %d\n",aux1, aux2);
            i = aux1;
            // printf("i %d\n", i);
            q_orig += 2;
            i = 1;

            *(q_orig) = aux1;
            *(q_orig + 1) = aux2;
            //printf("\t%d - %d\n", *q_orig, *(q_orig+1));

        }
    }
    int aux_num;

    q_orig = p_orig; //reinicializa ponteiro array
    printf("\n\tArray \n");
    for (i = 2; i <= ((*iter) * 2); i = i + 2) {

        //printf("\t\tarray %d ", *(q_orig+(i-1)));
        printf("\t%d -- %d", *(q_orig + i), *(q_orig + i + 1));
    }
    printf("\n\tArray \n");
/*
e 1 4
e 2 4
e 2 5
e 3 4
e 4 6
*/
    q_orig = p_orig; //reinicializa ponteiro array
    x = 1;
    int resultado[*n][*n];
    q_orig = p_orig; //reinicializa ponteiro array

    for (i = 2; i <= ((*n) * 2); i = i + 2) {
        arrayAux1[0] = *(q_orig + i);
        arrayAux1[1] = *(q_orig + i + 1);

        for (j = 1; j <= *n; j++) {
            arrayAux2[0] = j + 1;
            for (k = 1; k <= *n; k++) {
                arrayAux2[1] = k + 1;

                if (arrayAux1[0] == arrayAux2[0] && arrayAux1[1] == arrayAux2[1]) {
                    if (i >= 2 && resultado[j][k] == 1) {
                        resultado[j][k] = 0;
                    } else {
                        if (arrayAux1[0] == arrayAux1[1]) {
                            resultado[j][k] = 0;
                        } else {
                            resultado[j][k] = 1;
                        }
                    }
                } else {
                    if (i >= 2 && resultado[j][k] == 1) {
                        continue;
                    } else if (i >= 2 && resultado[j][k] == 0) {
                        resultado[j][k] = 0;
                    } else {
                        resultado[j][k] = 0;
                    }
                }
                // printf("[%d] [%d] ------- [%d] [%d] -> Resultado = %d\n",arrayAux1[0], arrayAux1[1], arrayAux2[0], arrayAux2[1], resultado[j][k]);
            }
        }
    }

    for (i = 1; i <= *n; i++) {
        int h = i-1;
        for (j = 1; j <= *n; j++) {
            int l = j;
            *(q+h+(h*l)) = resultado[i][j];
            printf(" [%d]", resultado[i][j]);
            //printf("  %d[%d]",i*j, resultado[i][j]);
        }
        printf("\n");
    }
    q = p; //reinicializa ponteiro array

    fclose(f);

    free(p_orig);
    return q;
}

// Gera a solucao inicial
// Parametros: solucao, numero de vertices
void gera_sol_inicial(int *sol, int v, int *mat, int num_iter) {
    int i, j, m, x, y, w=1;

    for (i = 0; i < v; i++) { // Para cada subconjunto
        // if (sol[i] != 0)
        *(sol+i) = -1;
    }


    for (i = 0; i < v; i++) {
        do {
            //printf("\nx %d j %d sol %d w %d", x, j, *(sol+j), w);
            x = random_l_h(1, v-1);
            //y = random_l_h(1, num_iter-1);
            for (j=0; j<v;j++) {
                for ( m = 0; m < v; m++) { // Para cada subconjunto
                    if (*(sol + m) == 0) {
                        if (*(mat + x + (m * x)) == 1) {
                            w = 1; //substitui para w 0
                        }else{w = 0;}
                    }
                }
                    if (*(mat + x + (j * x)) == 1) {
                        w = 1;
                    }else{w = 0;}
            }


        } while (w!=0);

        *(sol+x) = 0;
    }


}

// Escreve solucao
// Parametros: solucao e numero de vertices
void escreve_sol(int *sol, int vert, int *mat, int num_iter) {
    int i;

    printf("\nConjunto A: ");
    for (i = 0; i < vert; i++)
        if (sol[i] == 0)
            printf("%2d  ", i);

/*
printf("\nConjunto B: ");
for (i = 0; i < vert; i++)
    if (sol[i] == 1)
        printf("%2d  ", i);
*/
    printf("\n");
}

// copia vector b para a (tamanho n)
void substitui(int a[], int b[], int n) {
    int i, temp;
    for (i = 0; i < n; i++){

    a[i] = b[i];
    }
}

// Inicializa o gerador de numeros aleatorios
void init_rand() {
    srand((unsigned) time(NULL));
}

// Devolve valor inteiro aleatorio entre min e max
int random_l_h(int min, int max) {
    return min + rand() % (max - min + 1);
}

// Devolve um valor real aleatorio do intervalo [0, 1]
float rand_01() {
    return ((float) rand()) / RAND_MAX;
}

